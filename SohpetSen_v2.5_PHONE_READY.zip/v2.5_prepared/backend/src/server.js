import express from 'express';
import cors from 'cors';
import http from 'http';
import { Server } from 'socket.io';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import helmet from 'helmet';
import Database from 'better-sqlite3';

const app = express();
const isProduction = process.env.NODE_ENV === 'production';
const corsOrigin = process.env.CORS_ORIGIN || (isProduction ? '' : '*');
if (isProduction && !corsOrigin) throw new Error('CORS_ORIGIN üretimde zorunludur.');
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({contentSecurityPolicy:false,crossOriginEmbedderPolicy:false}));
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: corsOrigin || '*' } });
app.use(cors({origin: corsOrigin || '*', credentials: false}));
app.use(express.json({limit:'64kb'}));
const rate = new Map();
const authRate = new Map();
setInterval(()=>{const cutoff=Date.now()-120000;for(const [k,v] of rate){if(v.t<cutoff)rate.delete(k);}},60000).unref();
function authThrottle(req,res,next){const key=(req.ip||'unknown')+'|'+req.path;const nowMs=Date.now();const row=authRate.get(key)||{n:0,t:nowMs};if(nowMs-row.t>900000){row.n=0;row.t=nowMs;}row.n++;authRate.set(key,row);if(row.n>20)return res.status(429).json({error:'Çok fazla giriş/kayıt denemesi. 15 dakika sonra tekrar deneyin.'});next();}
function rateLimit(req,res,next){const key=(req.ip||'unknown')+'|'+req.path;const nowMs=Date.now();const row=rate.get(key)||{n:0,t:nowMs};if(nowMs-row.t>60000){row.n=0;row.t=nowMs;}row.n++;rate.set(key,row);if(row.n>120)return res.status(429).json({error:'Çok fazla istek. Lütfen biraz bekleyin.'});next();}
app.use('/api',rateLimit);
const db = new Database(process.env.DB_FILE || './sohpetsen.db');
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'user',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS rooms(id TEXT PRIMARY KEY,name TEXT NOT NULL,owner_id TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,room_id TEXT NOT NULL,user_id TEXT NOT NULL,username TEXT NOT NULL,text TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reports(id TEXT PRIMARY KEY,reporter_id TEXT NOT NULL,target_user_id TEXT,room_id TEXT,reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS room_members(room_id TEXT NOT NULL,user_id TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'listener',joined_at TEXT NOT NULL,PRIMARY KEY(room_id,user_id));
CREATE TABLE IF NOT EXISTS follows(follower_id TEXT NOT NULL,following_id TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(follower_id,following_id));
CREATE TABLE IF NOT EXISTS direct_messages(id TEXT PRIMARY KEY,sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,text TEXT NOT NULL,created_at TEXT NOT NULL,read_at TEXT);
CREATE TABLE IF NOT EXISTS wallets(user_id TEXT PRIMARY KEY,coins INTEGER NOT NULL DEFAULT 0,level INTEGER NOT NULL DEFAULT 1,xp INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS gifts(id TEXT PRIMARY KEY,name TEXT NOT NULL,cost INTEGER NOT NULL,icon TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS gift_events(id TEXT PRIMARY KEY,sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,room_id TEXT,gift_id TEXT NOT NULL,cost INTEGER NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS notifications(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,type TEXT NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL,read_at TEXT,created_at TEXT NOT NULL);`);
const DEFAULT_GIFTS=[['rose','Gül',10,'🌹'],['coffee','Kahve',25,'☕'],['crown','Taç',100,'👑'],['diamond','Elmas',500,'💎']];
for(const g of DEFAULT_GIFTS) db.prepare('INSERT OR IGNORE INTO gifts(id,name,cost,icon) VALUES(?,?,?,?)').run(...g);
const ensureWallet=u=>{db.prepare('INSERT OR IGNORE INTO wallets(user_id) VALUES(?)').run(u);return db.prepare('SELECT * FROM wallets WHERE user_id=?').get(u)};
const addNotification=(userId,type,title,body)=>{const n={id:id(),userId,type,title,body,createdAt:now()};db.prepare('INSERT INTO notifications(id,user_id,type,title,body,created_at) VALUES(?,?,?,?,?,?)').run(n.id,n.userId,n.type,n.title,n.body,n.createdAt);io.to('user:'+userId).emit('notification',n);return n};
const JWT_SECRET = process.env.JWT_SECRET || (process.env.NODE_ENV==='production' ? '' : crypto.randomBytes(48).toString('hex'));
if(JWT_SECRET.length < 32){ throw new Error('JWT_SECRET en az 32 karakter olmalıdır.'); }
if(!process.env.JWT_SECRET) console.warn('UYARI: Geliştirme için geçici JWT_SECRET üretildi; yeniden başlatmada oturumlar geçersiz olabilir.');
const now=()=>new Date().toISOString(); const id=()=>crypto.randomUUID();
const tokenFor=u=>jwt.sign({sub:u.id,username:u.username,role:u.role},JWT_SECRET,{expiresIn:'30d'});
function auth(req,res,next){try{req.user=jwt.verify((req.headers.authorization||'').replace(/^Bearer /,''),JWT_SECRET);const u=db.prepare('SELECT role FROM users WHERE id=?').get(req.user.sub);if(!u)return res.status(401).json({error:'Kullanıcı bulunamadı.'});if(u.role==='banned')return res.status(403).json({error:'Hesabınız askıya alınmış.'});req.user.role=u.role;next();}catch{res.status(401).json({error:'Yetkisiz'});}}
function admin(req,res,next){if(req.user?.role!=='admin')return res.status(403).json({error:'Admin yetkisi gerekli.'});next();}
app.get('/api/health',(_,res)=>res.json({ok:true,app:'SohpetSen',version:'2.5.0',database:'sqlite',environment:process.env.NODE_ENV||'development'}));
app.get('/api/ready',(_,res)=>{const production=process.env.NODE_ENV==='production';const checks={database:!!db,https:!production||!!process.env.PUBLIC_BASE_URL?.startsWith('https://'),jwt:JWT_SECRET.length>=32,cors:!production||!!process.env.CORS_ORIGIN};const ok=Object.values(checks).every(Boolean);res.status(ok?200:503).json({ok,checks});});
app.post('/api/register',authThrottle,async(req,res)=>{const username=String(req.body?.username||'').trim();const password=String(req.body?.password||'');if(username.length<3||username.length>24||password.length<6)return res.status(400).json({error:'Kullanıcı adı 3-24 karakter, şifre en az 6 karakter olmalı.'});try{const u={id:id(),username,passwordHash:await bcrypt.hash(password,10),role:'user',createdAt:now()};db.prepare('INSERT INTO users VALUES(?,?,?,?,?)').run(u.id,u.username,u.passwordHash,u.role,u.createdAt);res.status(201).json({token:tokenFor(u),user:{id:u.id,username:u.username,role:u.role}});}catch(e){res.status(409).json({error:'Kullanıcı adı kullanımda.'});}});
app.post('/api/login',authThrottle,async(req,res)=>{const username=String(req.body?.username||'').trim();const password=String(req.body?.password||'');const u=db.prepare('SELECT * FROM users WHERE lower(username)=lower(?)').get(username);if(!u||!(await bcrypt.compare(password,u.password_hash)))return res.status(401).json({error:'Giriş bilgileri hatalı.'});res.json({token:tokenFor({id:u.id,username:u.username,role:u.role}),user:{id:u.id,username:u.username,role:u.role}});});
app.get('/api/wallet',auth,(req,res)=>res.json(ensureWallet(req.user.sub)));
app.get('/api/gifts',auth,(_,res)=>res.json(db.prepare('SELECT id,name,cost,icon FROM gifts ORDER BY cost').all()));
app.post('/api/wallet/add-demo',auth,(req,res)=>{if(process.env.NODE_ENV==='production')return res.status(404).json({error:'Bulunamadı.'});const amount=Math.max(0,Math.min(10000,Number(req.body?.amount||0)));ensureWallet(req.user.sub);db.prepare('UPDATE wallets SET coins=coins+? WHERE user_id=?').run(amount,req.user.sub);res.json(ensureWallet(req.user.sub));});
app.post('/api/gifts/send',auth,(req,res)=>{const receiver=String(req.body?.receiverId||'');const giftId=String(req.body?.giftId||'');const roomId=req.body?.roomId?String(req.body.roomId):null;const gift=db.prepare('SELECT * FROM gifts WHERE id=?').get(giftId);if(!gift)return res.status(404).json({error:'Hediye bulunamadı.'});if(!db.prepare('SELECT id FROM users WHERE id=?').get(receiver))return res.status(404).json({error:'Alıcı bulunamadı.'});if(receiver===req.user.sub)return res.status(400).json({error:'Kendine hediye gönderemezsin.'});const w=ensureWallet(req.user.sub);if(w.coins<gift.cost)return res.status(400).json({error:'Yetersiz coin.'});const tx=db.transaction(()=>{db.prepare('UPDATE wallets SET coins=coins-? WHERE user_id=?').run(gift.cost,req.user.sub);ensureWallet(receiver);db.prepare('UPDATE wallets SET coins=coins+? WHERE user_id=?').run(gift.cost,receiver);const e={id:id(),senderId:req.user.sub,receiverId:receiver,roomId,giftId:gift.id,cost:gift.cost,createdAt:now()};db.prepare('INSERT INTO gift_events VALUES(?,?,?,?,?,?,?)').run(e.id,e.senderId,e.receiverId,e.roomId,e.giftId,e.cost,e.createdAt);return e});const e=tx();addNotification(receiver,'gift','Yeni hediye',`${req.user.username} sana ${gift.name} gönderdi ${gift.icon}`);io.to('user:'+receiver).emit('gift',e);res.status(201).json({event:e,wallet:ensureWallet(req.user.sub)});});
app.get('/api/notifications',auth,(req,res)=>res.json(db.prepare('SELECT id,type,title,body,read_at AS readAt,created_at AS createdAt FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100').all(req.user.sub)));
app.post('/api/notifications/read',auth,(req,res)=>{db.prepare('UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL').run(now(),req.user.sub);res.json({ok:true});});
app.get('/api/leaderboard',auth,(_,res)=>res.json(db.prepare('SELECT u.id,u.username,w.level,w.xp FROM wallets w JOIN users u ON u.id=w.user_id ORDER BY w.level DESC,w.xp DESC LIMIT 50').all()));
app.get('/api/me',auth,(req,res)=>{const u=db.prepare('SELECT id,username,role,created_at FROM users WHERE id=?').get(req.user.sub);u?res.json(u):res.status(404).json({error:'Kullanıcı bulunamadı.'});});
app.get('/api/rooms',(_,res)=>{const rows=db.prepare(`SELECT r.id,r.name,r.owner_id AS ownerId,r.created_at AS createdAt,(SELECT COUNT(*) FROM messages m WHERE m.room_id=r.id) AS messageCount FROM rooms r ORDER BY r.created_at DESC`).all();res.json(rows);});
app.post('/api/rooms',auth,(req,res)=>{const name=String(req.body?.name||'').trim();if(name.length>60)return res.status(400).json({error:'Oda adı en fazla 60 karakter olabilir.'});if(!name)return res.status(400).json({error:'Oda adı gerekli.'});const r={id:id(),name,ownerId:req.user.sub,createdAt:now()};db.prepare('INSERT INTO rooms VALUES(?,?,?,?)').run(r.id,r.name,r.ownerId,r.createdAt);res.status(201).json(r);});
app.get('/api/rooms/:id/members',auth,(req,res)=>{
 const exists=db.prepare('SELECT id FROM rooms WHERE id=?').get(req.params.id);
 if(!exists)return res.status(404).json({error:'Oda bulunamadı.'});
 res.json(db.prepare(`SELECT rm.user_id AS userId,u.username,rm.role,rm.joined_at AS joinedAt FROM room_members rm JOIN users u ON u.id=rm.user_id WHERE rm.room_id=? ORDER BY rm.joined_at`).all(req.params.id));
});
app.post('/api/rooms/:id/join',auth,(req,res)=>{
 const room=db.prepare('SELECT id,owner_id FROM rooms WHERE id=?').get(req.params.id);
 if(!room)return res.status(404).json({error:'Oda bulunamadı.'});
 const count=db.prepare('SELECT COUNT(*) c FROM room_members WHERE room_id=?').get(req.params.id).c;
 const existing=db.prepare('SELECT role FROM room_members WHERE room_id=? AND user_id=?').get(req.params.id,req.user.sub);
 if(!existing && count>=100)return res.status(409).json({error:'Oda kapasitesi dolu.'});
 const role=room.owner_id===req.user.sub?'owner':(existing?.role||'listener');
 db.prepare('INSERT INTO room_members(room_id,user_id,role,joined_at) VALUES(?,?,?,?) ON CONFLICT(room_id,user_id) DO UPDATE SET joined_at=excluded.joined_at').run(req.params.id,req.user.sub,role,now());
 io.to(`room:${req.params.id}`).emit('member:changed');
 res.json({ok:true,role});
});
app.post('/api/rooms/:id/leave',auth,(req,res)=>{db.prepare('DELETE FROM room_members WHERE room_id=? AND user_id=?').run(req.params.id,req.user.sub);io.to(`room:${req.params.id}`).emit('member:changed');res.json({ok:true});});
app.post('/api/rooms/:id/request-speaker',auth,(req,res)=>{
 const room=db.prepare('SELECT owner_id FROM rooms WHERE id=?').get(req.params.id);
 if(!room)return res.status(404).json({error:'Oda bulunamadı.'});
 const member=db.prepare('SELECT role FROM room_members WHERE room_id=? AND user_id=?').get(req.params.id,req.user.sub);
 if(!member)return res.status(403).json({error:'Önce odaya katılmalısınız.'});
 addNotification(room.owner_id,'speaker_request','Konuşmacı isteği',`${req.user.username} konuşmacı olmak istiyor.`);
 res.json({ok:true});
});
app.patch('/api/rooms/:id/members/:userId',auth,(req,res)=>{
 const room=db.prepare('SELECT owner_id FROM rooms WHERE id=?').get(req.params.id); if(!room)return res.status(404).json({error:'Oda bulunamadı.'});
 if(room.owner_id!==req.user.sub && req.user.role!=='admin')return res.status(403).json({error:'Bu işlem için oda sahibi veya admin olmalısınız.'});
 if(req.params.userId===req.user.sub)return res.status(400).json({error:'Kendi rolünü değiştiremezsin.'});
 const role=String(req.body?.role||'listener'); if(!['listener','speaker','muted','moderator'].includes(role))return res.status(400).json({error:'Geçersiz rol.'});
 const result=db.prepare('UPDATE room_members SET role=? WHERE room_id=? AND user_id=?').run(role,req.params.id,req.params.userId);
 if(!result.changes)return res.status(404).json({error:'Üye odada değil.'});
 io.to('user:'+req.params.userId).emit('room:roleChanged',{roomId:req.params.id,role});io.to(`room:${req.params.id}`).emit('member:changed');res.json({ok:true,role});
});
app.delete('/api/rooms/:id/members/:userId',auth,(req,res)=>{const room=db.prepare('SELECT owner_id FROM rooms WHERE id=?').get(req.params.id);if(!room)return res.status(404).json({error:'Oda bulunamadı.'});if(room.owner_id!==req.user.sub&&req.user.role!=='admin')return res.status(403).json({error:'Yetki yok.'});if(req.params.userId===req.user.sub)return res.status(400).json({error:'Kendini çıkaramazsın.'});const result=db.prepare('DELETE FROM room_members WHERE room_id=? AND user_id=?').run(req.params.id,req.params.userId);if(!result.changes)return res.status(404).json({error:'Üye odada değil.'});io.to('user:'+req.params.userId).emit('room:kicked',{roomId:req.params.id});io.to(`room:${req.params.id}`).emit('member:changed');res.json({ok:true});});
app.get('/api/rooms/:id/messages',(_,res)=>{const rows=db.prepare('SELECT id,user_id AS userId,username,text,created_at AS at FROM messages WHERE room_id=? ORDER BY created_at DESC LIMIT 100').all(_.params.id).reverse();res.json(rows);});
function saveMessage(roomId,user,text){const msg={id:id(),roomId,userId:user.sub,username:user.username,text,at:now()};db.prepare('INSERT INTO messages VALUES(?,?,?,?,?,?)').run(msg.id,msg.roomId,msg.userId,msg.username,msg.text,msg.at);return msg;}
app.post('/api/rooms/:id/messages',auth,(req,res)=>{if(!db.prepare('SELECT id FROM rooms WHERE id=?').get(req.params.id))return res.status(404).json({error:'Oda bulunamadı.'});const text=String(req.body?.text||'').trim();if(text.length>1000)return res.status(400).json({error:'Mesaj en fazla 1000 karakter olabilir.'});if(!text)return res.status(400).json({error:'Mesaj boş olamaz.'});const msg=saveMessage(req.params.id,req.user,text);io.to(`room:${req.params.id}`).emit('message',msg);res.status(201).json(msg);});
app.get('/api/users/search',auth,(req,res)=>{const q=String(req.query.q||'').trim();if(q.length<2)return res.json([]);res.json(db.prepare("SELECT id,username,role,created_at AS createdAt FROM users WHERE lower(username) LIKE lower(?) ORDER BY username LIMIT 30").all('%'+q+'%'));});
app.post('/api/users/:id/follow',auth,(req,res)=>{if(req.params.id===req.user.sub)return res.status(400).json({error:'Kendini takip edemezsin.'});if(!db.prepare('SELECT id FROM users WHERE id=?').get(req.params.id))return res.status(404).json({error:'Kullanıcı bulunamadı.'});db.prepare('INSERT OR IGNORE INTO follows VALUES(?,?,?)').run(req.user.sub,req.params.id,now());res.json({following:true});});
app.delete('/api/users/:id/follow',auth,(req,res)=>{db.prepare('DELETE FROM follows WHERE follower_id=? AND following_id=?').run(req.user.sub,req.params.id);res.json({following:false});});
app.get('/api/users/:id/following',auth,(req,res)=>res.json({following:!!db.prepare('SELECT 1 FROM follows WHERE follower_id=? AND following_id=?').get(req.user.sub,req.params.id)}));
app.get('/api/messages/conversations',auth,(req,res)=>{const rows=db.prepare(`SELECT u.id AS userId,u.username,dm.text,dm.created_at AS at FROM users u JOIN direct_messages dm ON dm.id=(SELECT d2.id FROM direct_messages d2 WHERE ((d2.sender_id=? AND d2.receiver_id=u.id) OR (d2.sender_id=u.id AND d2.receiver_id=?)) ORDER BY d2.created_at DESC LIMIT 1) WHERE u.id<>? ORDER BY dm.created_at DESC`).all(req.user.sub,req.user.sub,req.user.sub);res.json(rows);});
app.get('/api/messages/:userId',auth,(req,res)=>{const rows=db.prepare(`SELECT id,sender_id AS senderId,receiver_id AS receiverId,text,created_at AS at,read_at AS readAt FROM direct_messages WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY created_at ASC LIMIT 200`).all(req.user.sub,req.params.userId,req.params.userId,req.user.sub);db.prepare('UPDATE direct_messages SET read_at=? WHERE sender_id=? AND receiver_id=? AND read_at IS NULL').run(now(),req.params.userId,req.user.sub);res.json(rows);});
app.post('/api/messages/:userId',auth,(req,res)=>{const text=String(req.body?.text||'').trim();if(text.length>1000)return res.status(400).json({error:'Mesaj en fazla 1000 karakter olabilir.'});if(!text)return res.status(400).json({error:'Mesaj boş olamaz.'});if(!db.prepare('SELECT id FROM users WHERE id=?').get(req.params.userId))return res.status(404).json({error:'Kullanıcı bulunamadı.'});const m={id:id(),senderId:req.user.sub,receiverId:req.params.userId,text,at:now()};db.prepare('INSERT INTO direct_messages(id,sender_id,receiver_id,text,created_at) VALUES(?,?,?,?,?)').run(m.id,m.senderId,m.receiverId,m.text,m.at);io.to('user:'+req.params.userId).emit('dm',m);io.to('user:'+req.user.sub).emit('dm',m);res.status(201).json(m);});
app.post('/api/reports',auth,(req,res)=>{const reason=String(req.body?.reason||'').trim();if(!reason)return res.status(400).json({error:'Şikayet nedeni gerekli.'});const r={id:id(),reporterId:req.user.sub,targetUserId:req.body?.targetUserId||null,roomId:req.body?.roomId||null,reason,status:'open',createdAt:now()};db.prepare('INSERT INTO reports VALUES(?,?,?,?,?,?,?)').run(r.id,r.reporterId,r.targetUserId,r.roomId,r.reason,r.status,r.createdAt);res.status(201).json(r);});
app.get('/api/admin/stats',auth,admin,(_,res)=>res.json({users:db.prepare('SELECT COUNT(*) c FROM users').get().c,rooms:db.prepare('SELECT COUNT(*) c FROM rooms').get().c,reportsOpen:db.prepare("SELECT COUNT(*) c FROM reports WHERE status='open'").get().c,online:io.engine.clientsCount}));
app.get('/api/admin/reports',auth,admin,(_,res)=>res.json(db.prepare('SELECT * FROM reports ORDER BY created_at DESC LIMIT 200').all()));
app.get('/api/admin/users',auth,admin,(_,res)=>res.json(db.prepare('SELECT id,username,role,created_at AS createdAt FROM users ORDER BY created_at DESC LIMIT 500').all()));
app.patch('/api/admin/users/:id/role',auth,admin,(req,res)=>{const role=String(req.body?.role||'user');if(!['user','admin','moderator','banned'].includes(role))return res.status(400).json({error:'Geçersiz rol.'});db.prepare('UPDATE users SET role=? WHERE id=?').run(role,req.params.id);res.json({ok:true,role});});
app.patch('/api/admin/reports/:id',auth,admin,(req,res)=>{const status=String(req.body?.status||'open');if(!['open','reviewed','closed'].includes(status))return res.status(400).json({error:'Geçersiz durum.'});db.prepare('UPDATE reports SET status=? WHERE id=?').run(status,req.params.id);res.json({ok:true});});
app.delete('/api/me',auth,(req,res)=>{const uid=req.user.sub;const tx=db.transaction(()=>{db.prepare('DELETE FROM notifications WHERE user_id=?').run(uid);db.prepare('DELETE FROM gift_events WHERE sender_id=? OR receiver_id=?').run(uid,uid);db.prepare('DELETE FROM direct_messages WHERE sender_id=? OR receiver_id=?').run(uid,uid);db.prepare('DELETE FROM follows WHERE follower_id=? OR following_id=?').run(uid,uid);db.prepare('DELETE FROM room_members WHERE user_id=?').run(uid);db.prepare('DELETE FROM messages WHERE user_id=?').run(uid);db.prepare('DELETE FROM reports WHERE reporter_id=? OR target_user_id=?').run(uid,uid);db.prepare('DELETE FROM wallets WHERE user_id=?').run(uid);db.prepare('DELETE FROM rooms WHERE owner_id=?').run(uid);db.prepare('DELETE FROM users WHERE id=?').run(uid);});tx();res.json({ok:true});});
app.patch('/api/rooms/:id/members/:userId/role',auth,(req,res)=>{const room=db.prepare('SELECT owner_id FROM rooms WHERE id=?').get(req.params.id);if(!room)return res.status(404).json({error:'Oda bulunamadı.'});if(room.owner_id!==req.user.sub)return res.status(403).json({error:'Sadece oda sahibi rol değiştirebilir.'});const role=String(req.body?.role||'listener');if(!['listener','speaker','moderator'].includes(role))return res.status(400).json({error:'Geçersiz oda rolü.'});if(req.params.userId===req.user.sub)return res.status(400).json({error:'Kendi rolünü değiştiremezsin.'});const result=db.prepare('UPDATE room_members SET role=? WHERE room_id=? AND user_id=?').run(role,req.params.id,req.params.userId);if(!result.changes)return res.status(404).json({error:'Üye odada değil.'});io.to('user:'+req.params.userId).emit('room:roleChanged',{roomId:req.params.id,role});io.to('room:'+req.params.id).emit('member:changed');res.json({ok:true,role});});
app.delete('/api/rooms/:id/members/:userId',auth,(req,res)=>{const room=db.prepare('SELECT owner_id FROM rooms WHERE id=?').get(req.params.id);if(!room)return res.status(404).json({error:'Oda bulunamadı.'});if(room.owner_id!==req.user.sub)return res.status(403).json({error:'Sadece oda sahibi üyeyi çıkarabilir.'});if(req.params.userId===req.user.sub)return res.status(400).json({error:'Kendini çıkaramazsın.'});const result=db.prepare('DELETE FROM room_members WHERE room_id=? AND user_id=?').run(req.params.id,req.params.userId);if(!result.changes)return res.status(404).json({error:'Üye odada değil.'});io.to('user:'+req.params.userId).emit('room:kicked',{roomId:req.params.id});io.to('room:'+req.params.id).emit('member:changed');res.json({ok:true});});

io.use((socket,next)=>{try{socket.user=jwt.verify(socket.handshake.auth?.token||'',JWT_SECRET);next();}catch{next(new Error('Yetkisiz'));}});
io.on('connection',socket=>{
 socket.join('user:'+socket.user.sub);
 socket.on('joinRoom',roomId=>{if(!roomId||String(roomId).length>100)return;if(!db.prepare('SELECT id FROM rooms WHERE id=?').get(roomId))return; if(db.prepare("SELECT role FROM users WHERE id=?").get(socket.user.sub)?.role==='banned')return;const room=db.prepare('SELECT owner_id FROM rooms WHERE id=?').get(roomId); const existing=db.prepare('SELECT role FROM room_members WHERE room_id=? AND user_id=?').get(roomId,socket.user.sub); const role=room?.owner_id===socket.user.sub?'owner':(existing?.role||'listener'); db.prepare('INSERT INTO room_members(room_id,user_id,role,joined_at) VALUES(?,?,?,?) ON CONFLICT(room_id,user_id) DO UPDATE SET role=excluded.role,joined_at=excluded.joined_at').run(roomId,socket.user.sub,role,now());socket.join(`room:${roomId}`);socket.currentRoom=roomId;const peers=[...io.sockets.adapter.rooms.get(`room:${roomId}`)||[]].filter(id=>id!==socket.id); socket.emit('room:peers',peers); io.to(`room:${roomId}`).emit('presence',{type:'joined',username:socket.user.username}); });
 socket.on('leaveRoom',()=>{if(socket.currentRoom){const r=socket.currentRoom;db.prepare('DELETE FROM room_members WHERE room_id=? AND user_id=?').run(r,socket.user.sub);socket.leave(`room:${r}`);io.to(`room:${r}`).emit('presence',{type:'left',username:socket.user.username});io.to(`room:${r}`).emit('room:peerLeft',{id:socket.id});socket.currentRoom=null;}});
 socket.on('sendMessage',payload=>{if(!socket.currentRoom)return;const text=String(payload?.text||'').trim();if(!text||text.length>1000)return;const msg=saveMessage(socket.currentRoom,socket.user,text);io.to(`room:${socket.currentRoom}`).emit('message',msg);});
 // WebRTC signaling: media stays peer-to-peer; server only relays signaling data.
 const relayAllowed=(p)=>{const to=String(p?.to||'');return to && to.length<=100 && io.sockets.sockets.has(to) && socket.currentRoom && io.sockets.sockets.get(to)?.currentRoom===socket.currentRoom;};
 socket.on('webrtc:offer',p=>{if(relayAllowed(p))io.to(p.to).emit('webrtc:offer',{from:socket.id,offer:p.offer});});
 socket.on('webrtc:answer',p=>{if(relayAllowed(p))io.to(p.to).emit('webrtc:answer',{from:socket.id,answer:p.answer});});
 socket.on('webrtc:ice',p=>{if(relayAllowed(p))io.to(p.to).emit('webrtc:ice',{from:socket.id,candidate:p.candidate});});
 socket.on('room:peers',()=>{if(socket.currentRoom){const peers=[...io.sockets.adapter.rooms.get(`room:${socket.currentRoom}`)||[]].filter(id=>id!==socket.id);socket.emit('room:peers',peers);}});
 socket.on('disconnect',()=>{if(socket.currentRoom){const r=socket.currentRoom;db.prepare('DELETE FROM room_members WHERE room_id=? AND user_id=?').run(r,socket.user.sub);io.to(`room:${r}`).emit('presence',{type:'left',username:socket.user.username});io.to(`room:${r}`).emit('room:peerLeft',{id:socket.id});}});
});
const port=process.env.PORT||3000;server.listen(port,()=>console.log(`SohpetSen v2.5 backend on :${port}`));
