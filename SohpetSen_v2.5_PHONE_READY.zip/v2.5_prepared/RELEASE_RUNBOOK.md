# SohpetSen 2.3 release runbook

1. Set `NODE_ENV=production`.
2. Set a random `JWT_SECRET` (32+ chars).
3. Set `CORS_ORIGIN` and `PUBLIC_BASE_URL` to real HTTPS domains.
4. Put the API behind an HTTPS reverse proxy.
5. Use a managed PostgreSQL database before large public launch; SQLite is suitable for early testing.
6. Add TURN/SFU for large voice rooms; the current WebRTC mesh is intended for small rooms.
7. Set the Android release `API_BASE_URL` to the real HTTPS API.
8. Build and sign an Android App Bundle (AAB), then test it on physical devices.
