# SohpetSen yayın kontrol listesi

- [ ] HTTPS ve WSS
- [ ] Güçlü `JWT_SECRET`
- [ ] `CORS_ORIGIN` gerçek alan adı
- [ ] TURN sunucusu
- [ ] Büyük odalar için SFU
- [ ] Üretim veritabanı ve otomatik yedek
- [ ] Gizlilik politikası
- [ ] Kullanım şartları
- [ ] Hesap silme akışının son testi
- [ ] Şikâyet / engelleme / moderasyon testleri
- [ ] Google Play Data Safety ve içerik beyanları
- [ ] Uygulama imzalama ve release AAB
- [ ] Crash/log izleme
- [ ] Gerçek cihazlarda mikrofon, ses, arka plan ve ağ değişimi testleri
