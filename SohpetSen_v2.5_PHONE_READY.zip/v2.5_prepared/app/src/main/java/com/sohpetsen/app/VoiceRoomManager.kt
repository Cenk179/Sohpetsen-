package com.sohpetsen.app

import android.content.Context
import org.json.JSONObject
import org.webrtc.*
import io.socket.client.Socket
import java.util.concurrent.ConcurrentHashMap

/** Small-room WebRTC mesh voice manager. For large public rooms, replace mesh with an SFU. */
class VoiceRoomManager(private val context: Context, private val socket: Socket) {
    private val peers = ConcurrentHashMap<String, PeerConnection>()
    private var closed = false
    private val factory: PeerConnectionFactory
    private val localAudio: AudioTrack
    private var initialized = false

    init {
        if (!initialized) {
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context).createInitializationOptions()
            )
            initialized = true
        }
        val adm = JavaAudioDeviceModule.builder(context).createAudioDeviceModule()
        factory = PeerConnectionFactory.builder().setAudioDeviceModule(adm).createPeerConnectionFactory()
        val source = factory.createAudioSource(MediaConstraints())
        localAudio = factory.createAudioTrack("sohpetsen-audio", source)
        localAudio.setEnabled(false)
        installSocketHandlers()
    }

    private fun config(): PeerConnection.RTCConfiguration = PeerConnection.RTCConfiguration(
        listOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
    ).apply { sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN }

    private fun peer(id: String): PeerConnection? {
        peers[id]?.let { return it }
        val observer = object : PeerConnection.Observer {
            override fun onIceCandidate(c: IceCandidate) {
                socket.emit("webrtc:ice", JSONObject().apply {
                    put("to", id); put("candidate", JSONObject().apply {
                        put("sdpMid", c.sdpMid); put("sdpMLineIndex", c.sdpMLineIndex); put("candidate", c.sdp)
                    })
                })
            }
            override fun onTrack(t: RtpTransceiver) { /* WebRTC plays the received audio track through the audio device module. */ }
            override fun onSignalingChange(s: PeerConnection.SignalingState) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState) {}
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState) {}
            override fun onAddStream(s: MediaStream) {}
            override fun onRemoveStream(s: MediaStream) {}
            override fun onDataChannel(d: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onConnectionChange(s: PeerConnection.PeerConnectionState) {}
            override fun onStandardizedIceConnectionChange(s: PeerConnection.IceConnectionState) {}
            override fun onSelectedCandidatePairChanged(e: CandidatePairChangeEvent) {}
            override fun onAddTrack(r: RtpReceiver, m: Array<out MediaStream>) {}
        }
        val pc = factory.createPeerConnection(config(), observer) ?: return null
        pc.addTrack(localAudio)
        peers[id] = pc
        return pc
    }

    private fun installSocketHandlers() {
        socket.on("room:peers") { args ->
            val list = args.firstOrNull() as? org.json.JSONArray ?: return@on
            for (i in 0 until list.length()) createOffer(list.optString(i))
        }
        socket.on("room:peerLeft") { args ->
            val o = args.firstOrNull() as? JSONObject ?: return@on
            removePeer(o.optString("id"))
        }
        socket.on("webrtc:offer") { args ->
            val o = args.firstOrNull() as? JSONObject ?: return@on
            val from = o.optString("from")
            val offer = o.optJSONObject("offer") ?: return@on
            val pc = peer(from) ?: return@on
            val sdp = SessionDescription(SessionDescription.Type.fromCanonicalForm(offer.optString("type")), offer.optString("sdp"))
            pc.setRemoteDescription(SimpleSdpObserver { createAnswer(from, pc) }, sdp)
        }
        socket.on("webrtc:answer") { args ->
            val o = args.firstOrNull() as? JSONObject ?: return@on
            val answer = o.optJSONObject("answer") ?: return@on
            val pc = peers[o.optString("from")] ?: return@on
            val sdp = SessionDescription(SessionDescription.Type.fromCanonicalForm(answer.optString("type")), answer.optString("sdp"))
            pc.setRemoteDescription(SimpleSdpObserver(), sdp)
        }
        socket.on("webrtc:ice") { args ->
            val o = args.firstOrNull() as? JSONObject ?: return@on
            val c = o.optJSONObject("candidate") ?: return@on
            peers[o.optString("from")]?.addIceCandidate(IceCandidate(c.optString("sdpMid"), c.optInt("sdpMLineIndex"), c.optString("candidate")))
        }
    }

    private fun removePeer(id: String) {
        peers.remove(id)?.close()
    }

    private fun createOffer(id: String) {
        if (closed) return
        if (id.isBlank() || peers.containsKey(id)) return
        val pc = peer(id) ?: return
        pc.createOffer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription) {
                pc.setLocalDescription(SimpleSdpObserver(), desc)
                socket.emit("webrtc:offer", JSONObject().apply {
                    put("to", id); put("offer", JSONObject().apply { put("type", desc.type.canonicalForm()); put("sdp", desc.description) })
                })
            }
        }, MediaConstraints())
    }

    private fun createAnswer(id: String, pc: PeerConnection) {
        pc.createAnswer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription) {
                pc.setLocalDescription(SimpleSdpObserver(), desc)
                socket.emit("webrtc:answer", JSONObject().apply {
                    put("to", id); put("answer", JSONObject().apply { put("type", desc.type.canonicalForm()); put("sdp", desc.description) })
                })
            }
        }, MediaConstraints())
    }

    fun setMicrophoneEnabled(enabled: Boolean) { if (!closed) localAudio.setEnabled(enabled) }

    fun close() {
        if (closed) return
        closed = true
        peers.values.forEach { it.close() }
        peers.clear()
        localAudio.dispose()
        factory.dispose()
    }

    private class SimpleSdpObserver(private val success: (() -> Unit)? = null) : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription) { success?.invoke() }
        override fun onSetSuccess() { success?.invoke() }
        override fun onCreateFailure(error: String) {}
        override fun onSetFailure(error: String) {}
    }
}
